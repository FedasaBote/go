package main

func Cube(x float64) float64 {
	return x*x*x - 1 // intentionally bugged
}
