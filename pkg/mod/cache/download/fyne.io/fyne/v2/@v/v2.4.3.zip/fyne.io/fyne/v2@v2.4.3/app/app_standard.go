//go:build !debug && !release
// +build !debug,!release

package app

import "fyne.io/fyne/v2"

const buildMode = fyne.BuildStandard
