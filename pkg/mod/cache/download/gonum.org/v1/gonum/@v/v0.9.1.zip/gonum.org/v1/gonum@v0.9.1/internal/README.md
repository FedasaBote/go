# Gonum internal [![GoDoc](https://godoc.org/gonum.org/v1/gonum/internal?status.svg)](https://godoc.org/gonum.org/v1/gonum/internal)

This is the set of internal packages for the Gonum project.
